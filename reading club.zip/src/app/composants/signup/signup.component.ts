import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  lgform: FormGroup = this.fb.group({
    name: ['name'],
    mail :['mail'],
    username : ['username'],
    password: ['********'],
  });
  constructor(private fb: FormBuilder,private router: Router ) {}
  // ,private dataService: DataService
}
