export enum Affiliation {
    Owner = 'owner',
    Admin = 'admin',
    Member = 'member',
    Outcast = 'outcast',
  }