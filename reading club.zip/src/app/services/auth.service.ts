import { Injectable } from '@angular/core';
import { Iuser } from '../body/user/iuser';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  updateCurrentUser(firstName: string, lastName: string) {
    if (this.isAuthentificated()) {
      this.currentUser.firstName = firstName;
      this.currentUser.lastName = lastName;
    }
  }
  currentUser: Iuser = { id: 0, userName: '', firstName: '', lastName: '' }; 

  loginUser(username: string, password: string) {
    this.currentUser = {
      id: 1,
      userName: username,
      firstName: 'iyed',
      lastName: 'souda',
    };
  }

  isAuthentificated() {
    return !!this.currentUser;
  }

  logout() {
    localStorage.removeItem('state');
  }
}
