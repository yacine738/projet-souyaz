import { Departement } from "../enum/departements";
export class Affiliation {
  constructor(public departement: Departement) {}
}
