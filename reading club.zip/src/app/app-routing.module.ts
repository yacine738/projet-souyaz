import { NgModule, createComponent } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LivreComponent } from './composants/livre/livre.component';
import { DetailLivreComponent } from './composants/detail-livre/detail-livre.component';
import { AjouterLivreComponent } from './composants/ajouter-livre/ajouter-livre.component';
import { LoginComponent } from './composants/login/login.component';
import { DashboardComponent } from './services/dashboard/dashboard.component';
import { ErreurComponent } from './composants/erreur/erreur.component';
import { EventsComponent } from './body/events/events.component';
import { AboutComponent } from './body/about/about.component';
import { ContactComponent } from './body/contact/contact.component';
import { ListeventsComponent } from './body/events/listevents/listevents.component';
import { DetailEventsComponent } from './body/events/detail-events/detail-events.component';
import { CreateEventComponent } from './body/events/create-event/create-event.component';
import { EventRouteActivatorService } from './body/events/event-route-activator.service';
import { EventListResolverService } from './body/events/event-list-resolver.service';
import { CreateSessionComponent } from './body/events/create-session/create-session.component';

const routes: Routes = [

  { path: 'livre', component: LivreComponent },
  { path: 'livre/:id', component:DetailLivreComponent},
  { path: 'ajouter-book',component:AjouterLivreComponent},
  { path: 'login', component: LoginComponent },
  {path: 'dashboard' , component:DashboardComponent},

  { path: 'events', component:EventsComponent },
  { path: 'about', component:  AboutComponent},
  { path: 'contact', component: ContactComponent },
  { path: '', redirectTo: '/livre', pathMatch: 'full' },
  {path : 'events/new' , component:CreateEventComponent, canDeactivate:['canDeactivateCreateEvent']},
  { path: 'events', component: ListeventsComponent ,resolve:{events:EventListResolverService} },
  { path: 'events/:id', component: DetailEventsComponent, canActivate:[EventRouteActivatorService] },
  { path:'events/session/new' , component:CreateSessionComponent},
  { path: '', redirectTo:'/events', pathMatch:'full'},
  { path: '**', component: ErreurComponent },
  {
    path: 'user',
    loadChildren: () => import('./body/user/user.module').then((m) => m.Usermodule),
  },
];
  


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
