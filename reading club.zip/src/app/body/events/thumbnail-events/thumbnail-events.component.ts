import { Component, EventEmitter, Input, Output} from '@angular/core';
import { Ievent } from '../ievent';

@Component({
  selector: 'app-thumbnail-events',
  templateUrl: './thumbnail-events.component.html',
  styleUrls: ['./thumbnail-events.component.css']
})
export class ThumbnailEventsComponent {
  @Input() event: Ievent = {} as Ievent;
  @Output() eventClick = new EventEmitter();

  handleClick() {
    this.eventClick.emit(this.event.name);
  }

  getStartTimeClass() {
    if (this.event && this.event.time === '08:00 am') {
      return ['green', 'bold'];
    }
    return [];
  }

  getNormalTimeClass() {
    if (this.event) {
      return ['orange', 'bold'];
    }
    return [];
  }

  getLateTimeClass() {
    if (this.event && this.event.time === '10:00 am') {
      return ['red', 'bold'];
    }
    return [];
  }
}
