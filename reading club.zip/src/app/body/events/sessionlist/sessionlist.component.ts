import { Component, Input } from '@angular/core';
import { Isession } from '../ievent';

@Component({
  selector: 'app-sessionlist',
  templateUrl: './sessionlist.component.html',
  styleUrls: ['./sessionlist.component.css']
})
export class SessionlistComponent {
@Input() sessions:Isession[]=[]
}
