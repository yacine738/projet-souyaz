import { Component } from '@angular/core';
import { EventService } from '../event.service';
import { ActivatedRoute } from '@angular/router';
import { Ievent, Isession } from '../ievent';

@Component({
  selector: 'app-detail-events',
  templateUrl: './detail-events.component.html',
  styleUrls: ['./detail-events.component.css']
})
export class DetailEventsComponent {
  event: any;
  addmode: boolean = false;

  constructor(private eventService: EventService, private route: ActivatedRoute) {
    this.event = this.eventService.getEvent(+this.route.snapshot.params['id']);
  }

  addsession() {
    this.addmode = true;
  }

  SaveNewSession(session: Isession) {
    if (this.event.sessions) {
      const nextId = Math.max(this.event.sessions.map((s:any) => s.id)) + 1;
      session.id = nextId;
      this.event.sessions.push(session);
      this.eventService.updateEvent(this.event);
      this.addmode = false;
    }
  }

  canceladdsession() {
    this.addmode = false;
  }
}
