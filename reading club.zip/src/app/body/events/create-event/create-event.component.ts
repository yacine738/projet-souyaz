import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from '../event.service';
import { Ievent } from '../ievent';

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css']
})
export class CreateEventComponent {
  newEvent:Ievent[]=[];
  isModified: boolean = true;
  events = Object.values(Event);
 eventForm: any;

  constructor(private router: Router,private eventService:EventService) {}
saveEvent(formValues:any){
this.eventService.saveEvent(formValues)
this.router.navigate(['/events'])
}
  cancel() {
this.router.navigate(['/events'])   
}
}
