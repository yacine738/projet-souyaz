import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Ievent } from './ievent';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  EVENTS: Ievent[] = [
    {
      id: 1,
      name: 'jakarta',
      date: new Date(),
      time: '09:00 am',
      price: 30,
      location: {
        adress: '',
        city: '',
        country: '',
      },
      onlineUrl: '',
      sessions: []
    },
    {
      id: 5,
      name: 'fantasy',
      date: new Date(),
      time: '11:00 am',
      price: 40,
      location: {
        adress: '',
        city: '',
        country: ''
      },
      onlineUrl: ''
    }
  ];

  getEvents(): Observable<Ievent[]> {
    return new Observable<Ievent[]>(observer => {
      setTimeout(() => {
        observer.next(this.EVENTS);
        observer.complete();
      }, 100);
    });
  }

  getEvent(id: number): Ievent |undefined {
    return this.EVENTS.find((event: { id: number; }) => event.id === id);
  }

  saveEvent(event: Ievent): void {
    event.id = 999;
    event.sessions = [];
    this.EVENTS.push(event);
  }

  updateEvent(event: Ievent): void {
    let index = this.EVENTS.findIndex((x: { id: number; }) => x.id === event.id);
    if (index !== -1) {
      this.EVENTS[index] = event;
    }
  }
}
