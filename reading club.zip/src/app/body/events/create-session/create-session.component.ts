import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Isession } from '../ievent';

@Component({
  selector: 'app-create-session',
  templateUrl: './create-session.component.html',
  styleUrls: ['./create-session.component.css']
})
export class CreateSessionComponent implements OnInit {
  @Output() SavenewSession = new EventEmitter()
  @Output() canceladdSession = new EventEmitter()
  newSessionForm: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    presenter: new FormControl('', Validators.required),
    duration: new FormControl('', Validators.required),
    level: new FormControl('', Validators.required),
    abstract: new FormControl('', [Validators.required, Validators.maxLength(400)])
  });
newEvent: any;
  ngOnInit() {
      this.newEvent = {}; // Initialize newEvent
    }
    
    // this.name=new FormControl('',Validators.required)
    // this.presenter=new FormControl('',Validators.required)
    // this.duration=new FormControl('',Validators.required)
    // this.level=new FormControl('',Validators.required)
    // this.abstract=new FormControl('',[Validators.required,
    // Validators.maxLength(400),this.restrictedWords])
  

  saveSession(formValues: any) {
    let session: Isession = {
      id: undefined,
      name: formValues.name,
      duration: formValues.duration,
      level: formValues.level,
      presenter: formValues.presenter,
      abstract: formValues.abstract,
      voters: []
    };
    this.SavenewSession.emit(session);
  }

  cancel() {
    this.canceladdSession.emit();
  }
  
}
