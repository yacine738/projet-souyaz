import { Component, OnInit } from '@angular/core';
import { Ievent } from '../ievent';
import { EventService } from '../event.service';

@Component({
  selector: 'app-listevents',
  templateUrl: './listevents.component.html',
  styleUrls: ['./listevents.component.css']
})
export class ListeventsComponent implements OnInit {
  events: Ievent[] = [];

  constructor(private eventService: EventService) {
  }

  ngOnInit() {
this.eventService.getEvents().subscribe(events =>{this.events=events})  }

  handleEventClicked(data: Ievent) {
    console.log('received', data);
  }
}
