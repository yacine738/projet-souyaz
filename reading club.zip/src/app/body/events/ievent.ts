export interface Ievent {
    id:number,
    name:string,
    date:Date,
    time:string,
    price:number,
    location?:{
        adress:String,
        city:String,
        country:String,
    },
    onlineUrl?:String,
    sessions?:Isession[]
 }
 export interface Isession{
    id?:number,
    name:String,
    presenter:String,
    duration:number,
    level:String,
    abstract:String,
    voters:string[]
 }
