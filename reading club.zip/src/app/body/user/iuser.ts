export interface Iuser{
    id:number,
    firstName:String,
    lastName:String,
    userName:String,
}