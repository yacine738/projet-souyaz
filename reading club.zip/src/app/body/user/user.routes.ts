import { LoginComponent } from "src/app/composants/login/login.component"
import { ProfileComponent } from "./profile/profile.component"

export const userRoutes=[
    {path :'profile' ,Component:ProfileComponent},
    {path :'login' ,component:LoginComponent}
]
