import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { userRoutes } from "./user.routes"
import { ProfileComponent } from "./profile/profile.component";
import { ReactiveFormsModule } from "@angular/forms";

@NgModule({
    imports:[
        CommonModule,
        RouterModule.forChild(userRoutes),
        ReactiveFormsModule
    ],
    declarations:[
        ProfileComponent
    ],
    providers:[

    ]
})
export class Usermodule{

}