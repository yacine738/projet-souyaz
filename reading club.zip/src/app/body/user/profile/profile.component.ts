import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  profileForm: FormGroup = new FormGroup({
    firstName: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z].*')]),
    lastName: new FormControl('', Validators.required),
  });

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {}

  cancel() {
    this.router.navigate(['/events']);
  }

  saveProfile(formValues: any) {
    this.authService.updateCurrentUser(formValues.firstName, formValues.lastName);
    this.router.navigate(['/events']);
  }

  validateFirstName() {
    return this.profileForm.get('firstName')?.valid || this.profileForm.get('firstName')?.untouched;
  }

  validateLastName() {
    return this.profileForm.get('lastName')?.valid || this.profileForm.get('lastName')?.untouched;
  }
}
